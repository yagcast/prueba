<?php
include_once( dirname( __FILE__ ) . '/recent-posts.php' );