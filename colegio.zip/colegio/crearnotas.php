<?php
//include config
require_once('php/config.php');
 require_once('php/class_imgUpldr.php');
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 
 if(isset($_POST['submit'])){

 try{
$Nota_corte1=$_POST["Nota_corte1"];
$Nota_corte2=$_POST["Nota_corte2"];
$Nota_corte3=$_POST["Nota_corte3"];
$Nota_final=$_POST["Nota_final"];
$asignatura=$_POST["asignatura"];
$estudiante=$_POST["estudiante"];
// Inicializamos
 
	  $user->insertnotas($Nota_corte1,$Nota_corte2,$Nota_corte3,$Nota_final,$asignatura,$estudiante);
	  header('Location: crearnotas.php');
 }catch(Exception $e){
	  $e;
	 }
	} 

 


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>NOtas</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<?php include 'header.php'; ?>
<div id="content">
<h2>Agregar Notas</h2>
  <div class="row-fluid">
    <div class="span9">
<div class="widget-box">
  <div class="widget-content nopadding">
            <div class="widget-content nopadding">
          <form action="#" method="post" class="form-horizontal">
           <div class="control-group">
              <label class="control-label">Nota Corte 1</label>
              <div class="controls">
              <input type="number" step="0.01" class="span11" name="Nota_corte1" requiered>
              </div>
            </div>
           <div class="control-group">
              <label class="control-label">Nota Corte 2</label>
              <div class="controls">
               <input type="number" step="0.01" class="span11"  name="Nota_corte2" requiered>
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Nota Corte 3:</label>
              <div class="controls">
                 <input type="number" step="0.01" class="span11" name="Nota_corte3" requiered>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Nota Corte final:</label>
              <div class="controls">
                 <input type="number" step="0.01" class="span11" name="Nota_final" requiered>
              </div>
            </div>

  <div class="control-group">
              <label class="control-label">Asignatura:</label>
              <div class="controls">
               <select name="asignatura" requiered>
               
               <?php 
			   $Asiganturas = $user->traer_asignaturas();
			   foreach($Asiganturas as $asignatura){

                 echo '<option value="'.$asignatura['Asi_codigo'].'">'.$asignatura['Asi_nombre'].'</option>' ;
               }?>
               
             
                 
               </select>
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Estudiante:</label>
              <div class="controls">
              <?php
			   $Estudiantes = $user->traer_estudiantes();
			   
			  ?>
               <select name="estudiante" requiered>
               
               <?php 
			  
			   foreach($Estudiantes as $estudiante){

                 echo '<option value="'.$estudiante['Est_codigo'].'">'.$estudiante['Est_nombres'].' '.$estudiante['Est_apellidos'].'</option>' ;
               }?>
               
            
                 
               </select>
              </div>
            </div>
             

            

            <div class="form-actions">
              <button type="submit" class="btn btn-success" Name="submit">enviar</button>
            </div>
          </form>
        </div>




</div>
</div>
</div>
 <table class="table">
<tr>
<td colspan="2">Docentes</td>
</tr>
<tr>
<td>Estudiante</td>
<td>Asignatura</td>
<td>Corte 1</td>
<td>Corte 2</td>
<td>Corte 3</td>

<td>Nota Final</td>
</tr>

  <?php
  $notas = $user->traer_notas();
  //print(json_encode($notas));
  foreach($notas as $nota){
	  echo "<tr>";
	  echo "<td>".$nota["nombre"]." ".$nota["apellido"]."</td>";
	 echo "<td>".$nota["asignatura"]."</td>";
	  echo "<td>".$nota["Nota_corte1"]."</td>";
	  echo "<td>".$nota["Nota_corte2"]."</td>";
	  echo "<td>".$nota["Nota_corte3"]."</td>";
	  echo "<td>".$nota["Nota_final"]."</td>";
	 echo "</tr>";
	  }
  ?>
   
  </table>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
