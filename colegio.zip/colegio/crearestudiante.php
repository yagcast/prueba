<?php
//include config
require_once('php/config.php');
 require_once('php/class_imgUpldr.php');
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 
 if(isset($_POST['submit'])){

 try{
	 
$nombres=$_POST["nombres"];
$apellidos=$_POST["apellidos"];
$documento=$_POST["documento"];
$genero=$_POST["genero"];
$acudiente=$_POST["acudiente"];
$telefono=$_POST["telefono"];
 $direccion=$_POST["direccion"];
$curso=$_POST["curso"];
$estado=$_POST["estado"];



$subir = new imgUpldr;
	// Inicializamos
	$subir->init($_FILES["foto"]);
$foto=$subir->__get("r");
	  $user->insertEstudiante($nombres,$apellidos,$documento,$genero,$acudiente,$telefono,$direccion,$foto,$curso,$estado );
	 //header('Location: crearestudiante.php');
 }catch(Exception $e){
	  $e;
	 }
	} 

 


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Estudiantes</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div  >
  <h1>Colegio</h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Bienvenido</span> </a>
      
    </li>
   
 
  </ul>
</div>

<!--start-top-serch-->
 
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard2</a>
  <ul>
    <li ><a href="index2.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li> <li> <a href="crearnotas.php"><i class="icon icon-inbox"></i> <span>Notas</span></a> </li>
    <li><a href="crearestudiante.php"><i class="icon icon-th"></i> <span>Crear Estudiante</span></a></li>
    <li><a href="creardocente.php"><i class="icon icon-fullscreen"></i> <span>Crear Docente</span></a></li> <li><a href="crearcolegio.php"><i class="icon icon-fullscreen"></i> <span>Crear Colegio</span></a></li>
 <li><a href="crearasignatura.php"><i class="icon icon-fullscreen"></i> <span>Crear Asignatura</span></a></li> 
<li><a href="crearcurso.php"><i class="icon icon-fullscreen"></i> <span>Crear Curso</span></a></li>
<li><a href="seguimiento.php"><i class="icon icon-fullscreen"></i> <span>Seguimiento Estudiantes</span></a></li> </ul>
</div>
<div id="content">
<h2>Agregar Estudiantes</h2>
  <div class="row-fluid">
    <div class="span9">
<div class="widget-box">
  <div class="widget-content nopadding">
          <form action="#" method="post" class="form-horizontal" enctype="multipart/form-data">
            <div class="control-group">
              <label class="control-label">Nombres :</label>
              <div class="controls">
                <input type="text" class="span11" Name="nombres" placeholder="nombres" />
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Apellidos:</label>
              <div class="controls">
                <input type="text" class="span11" Name="apellidos" placeholder="Apellidos" />
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Documento:</label>
              <div class="controls">
                <input type="text" class="span11" Name="documento" placeholder="Documento" />
              </div>
            </div>

 <div class="control-group">
              <label class="control-label">Genero</label>
              <div class="controls">
               <select name="genero">
                  <option value="M" >M</option>
                  <option value="F">F</option>
                  
               </select>
              </div>
            </div>

             <div class="control-group">
              <label class="control-label">Acudiente:</label>
              <div class="controls">
                <input type="text" class="span11" Name="acudiente" placeholder="Acudiente" />
              </div>
            </div>



            <div class="control-group">
              <label class="control-label">Telefono:</label>
              <div class="controls">
                <input type="number" class="span11" Name="telefono" placeholder="Telefono" />
              </div>
            </div>

           
            <div class="control-group">
              <label class="control-label">Direccion:</label>
              <div class="controls">
                <input type="text" class="span11" Name="direccion" placeholder="DIreccion" />
              </div>
            </div>

             <div class="control-group">
              <label class="control-label">Foto:</label>
              <div class="controls">
                <input type="file" class="span11" Name="foto" placeholder="foto" />
              </div>
            </div>
           <div class="control-group">
              <label class="control-label">Curso:</label>
              <div class="controls">
               <select name="curso">
              
               <?php
			    $cursos = $user->traer_cursos();
			    foreach($cursos as $curso){

                 echo '<option value="'.$curso['Cur_codigo'].'">'.$curso['Cur_nombre'].'</option>' ;
               }?>
               
             
                 
               </select>
              </div>
            </div>
             

 <div class="control-group">
              <label class="control-label">Estado</label>
              <div class="controls">
               <select name="estado">
                  <option value="Activo" >Activo</option>
                  <option value="Inactivo">Inactivo</option>
                  
               </select>
              </div>
            </div>

            <div class="form-actions">
              <button type="submit" class="btn btn-success" Name="submit">enviar</button>
            </div>
          </form>
        </div>


</div>
</div>
</div>
 <table class="table">
<tr>
<td colspan="2">Estudiantes</td>
</tr>
<tr>
<td>Documento</td>
<td>Nombres</td>
<td>Telefono</td>
</tr>

  <?php
  $cursos = $user->traer_estudiantes();
  
  foreach($cursos as $curso){
	  echo "<tr>";
	  echo "<td>".$curso["Est_documento"]."</td>";
	 echo "<td>".$curso["Est_nombres"]." ".$curso["Est_apellidos"]."</td>";
	  echo "<td>".$curso["Est_telefono"]."</td>";
	 echo "</tr>";
	  }
  ?>
   
  </table>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
