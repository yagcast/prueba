<?php
//include config
require_once('php/config.php');
 $curso=$_GET["curso"];
 $_SESSION["curso"]=$curso;
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 

 $cursos1 = $user->traer_cursos2($curso);
if(count($cursos1)>1){
foreach($cursos1 as $cur){
 $codigo=  $cur["Cur_codigo"];
 $nombre=  $cur["Cur_nombre"];
 $ano=  $cur["Cur_ano"];
}
}
if(isset($_POST['baja'])){

 try{
	
	$estudiante=$_POST["estudiante"];
 
	 $user->asignarestudiante($estudiante,' ' );
	 header('Location: asignarnotas.php?asignatura='.$asignatura.'');
 }catch(Exception $e){
	 echo $e;
	 }
	} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Colegio</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<?php include 'header.php'; ?>


<div id="content">
<div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div  class="quick-actions_homepage">
    <ul class="quick-actions">
     <li class="bg_ls"> <a href="index2.php"> <i class="icon-dashboard"></i> Home </a> </li>
    <li class="bg_lh"> <a href="menuporcurso.php?curso=<?php echo  $codigo?>"> <i class="icon-dashboard"></i> Home  <?php echo  $nombre?></a> </li>
      <li class="bg_lb"> <a href="agregarparticipante.php"> <i class="icon-dashboard"></i> Agregar Participantes a  <?php echo  $nombre?></a> </li>
      <li class="bg_lg"> <a href="agregarasignatura.php"> <i class="icon-shopping-cart"></i> Agregar Asignaturas a  <?php echo  $nombre?></a> </li>
       
 
    </ul>
  </div>
        <div class="widget-box">
          
          <div class="widget-content">
            <div class="error_ex">
<h2>  <?php echo  $nombre?></h2>
 
   
 

 
     <div class="row-fluid">
   
      <div class="span4">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-eye-open"></i> </span>
            <h5>Asiganturas del curso</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Nombre</th>
                   
                </tr>
              </thead>
              <tbody>
                <?php
     $asignaturas = $user->traer_asignaturas1($curso);
 foreach($asignaturas as $asign){ ?>
                <tr>
                  <td><a href="asignarnotas.php?asignatura=<?php echo $asign["Asi_codigo"];?>"><?php   $nombre=  $asign["Asi_nombre"];
 echo $nombre;?></a>
                </tr>
                 <?php
}
 ?>
                 
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
       <div class="span4">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-eye-open"></i> </span>
            <h5>Estudiantes Matriculados al curso</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Nombres del estudiante</th>
                   <th>Dar Baja</th>
                </tr>
              </thead>
              <tbody>
                <?php
     $estudiantes = $user->traer_estudiantescurso($curso);
 foreach($estudiantes as $est){ ?>
                <tr>
                  <td><?php   $nombre=  $est["Est_nombres"]." ". $est["Est_apellidos"] ;
 echo $nombre;?></td>
                   </td>
 <form  action="" method="post">
 <input type="hidden" name="estudiante" value="<?php echo  $est["Est_codigo"] ?>">
 				 <td> <button type="submit" class="btn-danger" Name="baja">Reitrar</button></td>
                  </form> 
                </tr>
                 <?php
}
 ?>
                 
              </tbody>
            </table>
          </div>
        </div>
      </div>
      

 
       
    </div>
 
</div> </div> </div> </div> </div> </div> </div> 
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
