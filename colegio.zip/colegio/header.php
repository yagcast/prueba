<!--Header-part-->
<div  >
  <h1>Colegio</h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title=""  data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Bienvenido</span> </a>
      
    </li>
   
   <li  class="dropdown" id="profile-messages" ><a title="" href="cerrar.php"  ><i class="icon icon-user"></i>  <span class="text">Cerrar Sesion</span> </a>
      
    </li>
  </ul>
</div>

<!--start-top-serch-->
 
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard2</a>
  <ul>
    <li ><a href="index2.php"><i class="icon icon-home"></i> <span>HOME</span></a> </li>
    <?php if($_SESSION['Per_codigo']==1){?>
     <li> <a href="crearnotas.php"><i class="icon icon-inbox"></i> <span>Notas</span></a> </li>
    <li><a href="crearestudiante.php"><i class="icon icon-th"></i> <span>Crear Estudiante</span></a></li>
    <li><a href="creardocente.php"><i class="icon icon-fullscreen"></i> <span>Crear Docente</span></a></li> <li><a href="crearcolegio.php"><i class="icon icon-fullscreen"></i> <span>Crear Colegio</span></a></li>
 <li><a href="crearasignatura.php"><i class="icon icon-fullscreen"></i> <span>Crear Asignatura</span></a></li> 
<li><a href="crearcurso.php"><i class="icon icon-fullscreen"></i> <span>Crear Curso</span></a></li>
<li><a href="seguimiento.php"><i class="icon icon-fullscreen"></i> <span>Seguimiento Estudiantes</span></a></li> 
<?php
}
?>
</ul>
</div>
