<?php
//include config
require_once('php/config.php');
 require_once('php/class_imgUpldr.php');
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 
 if(isset($_POST['submit'])){

 try{
$dateano=$_POST["dateano"];
$periodo=$_POST["periodo"];
$observacion=$_POST["observacion"];
$estudiante=$_POST["estudiante"];
// Inicializamos
 
	  $user->insertseguimiento($dateano,$periodo,$observacion,$estudiante);
	  header('Location: seguimiento.php');
 }catch(Exception $e){
	  $e;
	 }
	} 

 


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Seguimiento</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div  >
  <h1>Colegio</h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Bienvenido</span> </a>
      
    </li>
   
 
  </ul>
</div>

<!--start-top-serch-->
 
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard2</a>
  <ul>
    <li ><a href="index2.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
   
    <li> <a href="crearnotas.php"><i class="icon icon-inbox"></i> <span>Notas</span></a> </li>
    <li><a href="crearestudiante.php"><i class="icon icon-th"></i> <span>Crear Estudiante</span></a></li>
    <li><a href="creardocente.php"><i class="icon icon-fullscreen"></i> <span>Crear Docente</span></a></li> <li><a href="crearcolegio.php"><i class="icon icon-fullscreen"></i> <span>Crear Colegio</span></a></li>
 <li><a href="crearasignatura.php"><i class="icon icon-fullscreen"></i> <span>Crear Asignatura</span></a></li> 
<li><a href="crearcurso.php"><i class="icon icon-fullscreen"></i> <span>Crear Curso</span></a></li>
<li><a href="seguimiento.php"><i class="icon icon-fullscreen"></i> <span>Seguimiento Estudiantes</span></a></li>


</ul>
</div>
<div id="content">
<h2>eguimiento</h2>
  <div class="row-fluid">
    <div class="span9">
<div class="widget-box">
  <div class="widget-content nopadding">
          <form action="#" method="post" class="form-horizontal">
           <div class="control-group">
              <label class="control-label">Año</label>
              <div class="controls">
               <select name="dateano">
                  <option value="2017" >2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
               </select>
              </div>
            </div>
           <div class="control-group">
              <label class="control-label">Periodo</label>
              <div class="controls">
               <select name="periodo">
                  <option value="1" >1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  
               </select>
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Observacion:</label>
              <div class="controls">
                 <textarea class="span11" name="observacion" ></textarea>
              </div>
            </div>

  <div class="control-group">
              <label class="control-label">Estudiante:</label>
              <div class="controls">
               <select name="estudiante">
               <?php 
			    $Estudiantes = $user->traer_estudiantes();
			   foreach($Estudiantes as $estudiante){

                 echo '<option value="'.$estudiante['Est_codigo'].'">'.$estudiante['Est_nombres'].' '.$estudiante['Est_apellidos'].'</option>' ;
               }?>
               
            
                 
               </select>
              </div>
            </div>
             

            

            <div class="form-actions">
              <button type="submit" class="btn btn-success" Name="submit">enviar</button>
            </div>
          </form>
        </div>





</div>
</div>
</div>
 <table class="table">
<tr>
<td colspan="2">Seguimiento Estudiantes</td>
</tr>
<tr>
<td>Estudiante</td>
<td>Observacion</td>
<td>Año</td>
<td>Periodo</td>
 
</tr>

  <?php
  $seguimientos = $user->traer_seguimiento();
  //print(json_encode($notas));
  foreach($seguimientos as $seguimiento){
	  echo "<tr>";
	  echo "<td>".$seguimiento["nombre"]." ".$seguimiento["apellido"]."</td>";
	 echo "<td>".$seguimiento["Observacion"]."</td>";
	  echo "<td>".$seguimiento["Seg_año"]."</td>";
	  echo "<td>".$seguimiento["Periodo"]."</td>";
	 
	 echo "</tr>";
	  }
  ?>
   
  </table>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
