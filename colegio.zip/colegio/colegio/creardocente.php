<?php
//include config
require_once('php/config.php');
 require_once('php/class_imgUpldr.php');
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 
 if(isset($_POST['submit'])){

 try{
$cedula=$_POST["cedula"];
$nombres=$_POST["nombres"];
$apellidos=$_POST["apellidos"];
$genero=$_POST["genero"];
$telefono=$_POST["telefono"];
$correo=$_POST["correo"];
$usuario=$_POST["usuario"];
 

 



 
	// Inicializamos
 
	  $user->insertdocente($cedula,$nombres,$apellidos,$genero,$telefono,$correo,$usuario);
	  header('Location: crearestudiante.php');
 }catch(Exception $e){
	  $e;
	 }
	} 

 


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Estudiantes</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<?php include 'header.php'; ?>
<div id="content">
<h2>Agregar Estudiantes</h2>
  <div class="row-fluid">
    <div class="span9">
<div class="widget-box">
  <div class="widget-content nopadding">
          <form action="#" method="post" class="form-horizontal">
           <div class="control-group">
              <label class="control-label">Cedula:</label>
              <div class="controls">
              <input type="text"  class="span11" name="cedula" requiered>
              </div>
            </div>
           <div class="control-group">
              <label class="control-label">Nombres:</label>
              <div class="controls">
             <input type="text"  class="span11" name="nombres" requiered>
              </div>
            </div>

  <div class="control-group">
              <label class="control-label">Apellidos:</label>
              <div class="controls">
             <input type="text"  class="span11" name="apellidos" requiered>
              </div>
            </div>


 <div class="control-group">
              <label class="control-label">Genero</label>
              <div class="controls">
               <select name="genero">
                  <option value="M" >M</option>
                  <option value="F">F</option>
                  
               </select>
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Telefono</label>
              <div class="controls">
                 <input type="number"   class="span11" name="telefono" requiered>
              </div>
            </div>

 <div class="control-group">
              <label class="control-label">Correo:</label>
              <div class="controls">
                 <input type="email"   class="span11" name="correo" requiered>
              </div>
            </div>

                  <div class="control-group">
              <label class="control-label">Usuario:</label>
              <div class="controls">
               <select name="usuario" requiered>
            
               <?php 
			     
				 $usuarios = $user->traer_usuarios();
			   foreach($usuarios as $usuario){

                 echo '<option value="'.$usuario['Usu_codigo'].'">'.$usuario['Usu_nombre'].'</option>' ;
               }?>
               
          
                 
               </select>
              </div>
            </div>

   

            

            <div class="form-actions">
              <button type="submit" class="btn btn-success" Name="submit">enviar</button>
            </div>
          </form>
        </div>



</div>
</div>
</div>
 <table class="table">
<tr>
<td colspan="2">Docentes</td>
</tr>
<tr>
<td>Cedula</td>
<td>Nombres</td>
<td>Usuario</td>
</tr>

  <?php
  $cursos = $user->traer_Docentes();
  
  foreach($cursos as $curso){
	  echo "<tr>";
	  echo "<td>".$curso["Doc_cedula"]."</td>";
	 echo "<td>".$curso["Doc_nombres"]." ".$curso["Doc_apellidos"]."</td>";
	  echo "<td>".$curso["nombreusu"]."</td>";
	 echo "</tr>";
	  }
  ?>
   
  </table>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
