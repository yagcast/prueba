<?php
//include config
require_once('php/config.php');
 require_once('php/class_imgUpldr.php');
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }
 
 if(isset($_POST['submit'])){

 try{
	 
$nit=$_POST["nit"];
$nombre=$_POST["nombre"];
$direccion=$_POST["direccion"];
$telefono=$_POST["telefono"];
$rector=$_POST["rector"];
 
$subir = new imgUpldr;
	// Inicializamos
	$subir->init($_FILES["logo"]);
$logo=$subir->__get("r");
	  $user->insertColegio($nit,$nombre,$direccion,$telefono,$rector,$logo );
	header('Location: crearcolegio.php');
 }catch(Exception $e){
	  $e;
	 }
	} 

 


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Colegio</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<?php include 'header.php'; ?>
<div id="content">
<h2>Agregar Colegios</h2>
  <div class="row-fluid">
    <div class="span9">
<div class="widget-box">
 <div class="widget-content nopadding">
          <form action="#" method="post" class="form-horizontal" enctype="multipart/form-data">
            <div class="control-group">
              <label class="control-label">Nit :</label>
              <div class="controls">
                <input type="text" class="span11" Name="nit" placeholder="nit" />
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Nombre:</label>
              <div class="controls">
                <input type="text" class="span11" Name="nombre" placeholder="Nombre" />
              </div>
            </div>

              <div class="control-group">
              <label class="control-label">Direccion:</label>
              <div class="controls">
                <input type="text" class="span11" Name="direccion" placeholder="Direccion" />
              </div>
            </div>

 <div class="control-group">
              <label class="control-label">Telefono:</label>
              <div class="controls">
                <input type="text" class="span11" Name="telefono" placeholder="Telefono" />
              </div>
            </div>

             <div class="control-group">
              <label class="control-label">Rector:</label>
              <div class="controls">
                <input type="text" class="span11" Name="rector" placeholder="Rector" />
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">logo:</label>
              <div class="controls">
                <input type="file" name="logo"/>
              </div>
            </div>

           
          
             
            <div class="form-actions">
              <button type="submit" class="btn btn-success" Name="submit">enviar</button>
            </div>
          </form>
        </div>

</div>
</div>
</div>
 <table class="table">
<tr>
<td colspan="2">Colegios</td>
</tr>
<tr>
<td>Nombre</td>
<td>Direccion</td>
<td>Telefono</td>
</tr>

  <?php
  $cursos = $user->traer_colegios();
  
  foreach($cursos as $curso){
	  echo "<tr>";
	  echo "<td>".$curso["Col_nombre"]."</td>";
	 echo "<td>".$curso["Col_direccion"]."</td>";
	  echo "<td>".$curso["Col_telefono"]."</td>";
	 echo "</tr>";
	  }
  ?>
   
  </table>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
