<?php
include('password.php');
class User extends Password{

    private $_db;

    function __construct($db){
    	parent::__construct();

    	$this->_db = $db;
    }

	private function get_user_hash($username){

		try {
			$stmt = $this->_db->prepare('SELECT Usu_clave, Usu_nombre, usu.Usu_codigo, doc.Doc_cedula FROM usuario usu INNER JOIN docente doc ON   doc.Usu_codigo=usu.Usu_codigo WHERE Usu_nombre = :username  ');
			$stmt->execute(array('username' => $username));

			return $stmt->fetch();

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}

	public function isValidUsername($username){
		if (strlen($username) < 3) return false;
		if (strlen($username) > 17) return false;
		if (!ctype_alnum($username)) return false;
		return true;
	}

	public function login($username,$password){
		if (!$this->isValidUsername($username)) return false;
		if (strlen($password) < 3) return false;

		$row = $this->get_user_hash($username);
	 
		if(md5($password)==$row['Usu_clave']){

		    $_SESSION['loggedin'] = true;
		    $_SESSION['Usu_nombre'] = $row['Usu_nombre'];
		    $_SESSION['Usu_codigo'] = $row['Usu_codigo'];
			$_SESSION['Per_codigo'] = $row['Per_codigo'];
			$_SESSION['Doc_cedula'] = $row['Doc_cedula'];
		    return true;
		}
	}

	public function logout(){
		session_destroy();
	}

	public function is_logged_in(){
		if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
			return true;
		}
	}
	
	public function traer_cursos1($ano, $docente){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM curso where Cur_ano='.$ano.' AND Doc_Cedula='.$docente.'');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
		
	public function traer_cursos2($curso){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM curso where Cur_codigo='.$curso.'');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_cursos(){

		try {
			$stmt = $this->_db->prepare('SELECT *, doc. FROM curso inner join docente doc on docente.Doc_cedula=curso.Doc_cedula ');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function traer_asignaturas(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM asignatura');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_asignaturas1($curso){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM asignatura where Cur_codigo ='.$curso.'');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function traer_estudiantes(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM estudiante');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
		public function traer_estudiantescurso($curso){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM estudiante  where Est_estado="Activo" AND  Cur_codigo ='.$curso.' ');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
		public function traer_estudianteslibres(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM estudiante where Est_estado="Activo"');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function traer_anios(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM anhos');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_usuarios(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM usuario');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_Docentes(){

		try {
			$stmt = $this->_db->prepare('SELECT docente.*, usu.Usu_nombre as nombreusu FROM docente inner join usuario usu on docente.Usu_codigo=usu.Usu_codigo ');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_DocentesALL(){

		try {
			$stmt = $this->_db->prepare('SELECT docente.* FROM docente');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function traer_notas(){

		try {
			$stmt = $this->_db->prepare('SELECT notas.*, est.Est_nombres nombre, est.Est_apellidos as apellido, asi.Asi_nombre as asignatura FROM notas inner join estudiante est on notas.Est_codigo=est.Est_codigo  inner join asignatura asi on notas.Asi_codigo=asi.Asi_codigo');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function traer_notasestudiante($estudiante, $asignatura){

		try {
			$stmt = $this->_db->prepare('SELECT  *  FROM notas where Est_codigo='.$estudiante.' AND Asi_codigo='.$asignatura.'');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	
	public function traer_seguimiento(){

		try {
			$stmt = $this->_db->prepare('SELECT seguimiento.*, est.Est_nombres nombre, est.Est_apellidos as apellido FROM seguimiento inner join estudiante est on seguimiento.Est_codigo=est.Est_codigo');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function traer_colegios(){

		try {
			$stmt = $this->_db->prepare('SELECT * FROM colegio');
			   $stmt->execute();
  		$cursos = $stmt->fetchAll();
       return $cursos;
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
		public function insertcurso($codigo, $curso){

		try {
			$stmt = $this->_db->prepare('Insert into curso values(:codigo, :curso)');
			$stmt->execute(array('codigo' => $codigo, 'curso' => $curso));
			 
  		 
       return "exito";
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	 public function asignarestudiante($codigo, $curso){

		try {
			$stmt = $this->_db->prepare('UPDATE estudiante SET Cur_codigo=:curso where Est_codigo=:codigo ');
			$stmt->execute(array('codigo' => $codigo, 'curso' => $curso));
			 
  		 
       return "exito";
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	

	
	public function insertasignatura ($nombre,$curso){

		try {
			$stmt = $this->_db->prepare('Insert into   asignatura (Asi_nombre, Cur_codigo )values(:nombre,:curso)');
			$stmt->execute(array( 'nombre' => $nombre,  'curso' => $curso));
			 
  		 
       return "exito";
			 

		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function insertColegio($nit,$nombre,$direccion,$telefono,$rector,$logo ){

		try {
			$stmt = $this->_db->prepare('Insert into colegio values(:nit,:nombre,:direccion,:telefono,:rector,:logo)');
			$stmt->execute(array( 'nit' => $nit, 'nombre' => $nombre, 'direccion' => $direccion, 'telefono' => $telefono, 'rector' => $rector, 'logo' => $logo));
			 
  		 
       return "exito";
 




		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	 


	public function insertEstudiante($nombres,$apellidos,$documento,$genero,$acudiente,$telefono,$direccion,$foto,$curso,$estado ){

		try {
			$stmt = $this->_db->prepare('Insert into estudiante (Est_nombres,Est_apellidos,	Est_documento,	Est_genero,Est_acudiente,Est_telefono,	Est_direccion,Est_foto,Cur_codigo,Est_estado)values(:nombres,:apellidos,:documento,:genero,:acudiente,:telefono,:direccion,:foto,:curso,:estado)');
$stmt->execute(array('nombres' => $nombres, 'apellidos' => $apellidos, 'documento' => $documento, 'genero' => $genero, 'acudiente' => $acudiente, 'telefono' => $telefono,'direccion' => $direccion ,'foto' => $foto, 'curso' => $curso, 'estado' => $estado));
			 
  		 
       return "exito";
 




		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	public function insertdocente($cedula,$nombres,$apellidos,$genero,$telefono,$correo,$usuario ){

		try {
			$stmt = $this->_db->prepare('Insert into docente  values(:cedula,:nombres,:apellidos,:genero,:telefono,:correo,:usuario)');
$stmt->execute(array('cedula' => $cedula, 'nombres' => $nombres, 'apellidos' => $apellidos, 'genero' => $genero, 'telefono' => $telefono, 'correo' => $correo, 'usuario' => $usuario));
			 
  		 
       return "exito";
 




		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function insertnotas($Nota_corte1,$Nota_corte2,$Nota_corte3,$Nota_final,$asignatura,$estudiante ){

		try {
			
			
			$stmt = $this->_db->prepare('Select  *  FROM notas WHERE  Asi_codigo=:asignatura AND 	Est_codigo=:estudiante');
$stmt->execute(array( 'asignatura' => $asignatura, 'estudiante' => $estudiante));
			  
  		  $cuenta = $stmt->rowCount();
			if($cuenta==0){
			$stmt1 = $this->_db->prepare('Insert into notas  values(:Nota_final,:Nota_corte1,:Nota_corte2,:Nota_corte3, :asignatura,:estudiante)');
$stmt1->execute(array('Nota_final' => $Nota_final, 'Nota_corte1' => $Nota_corte1, 'Nota_corte2' => $Nota_corte2, 'Nota_corte3' => $Nota_corte3, 'asignatura' => $asignatura, 'estudiante' => $estudiante));
			  
			}else{
				$stmt2 = $this->_db->prepare('UPDATE  notas  SET   Nota_final=:Nota_final, Nota_corte1=:Nota_corte1,Nota_corte2=:Nota_corte2,Nota_corte3=:Nota_corte3 WHERE  Asi_codigo=:asignatura and Est_codigo=:estudiante ');
$stmt2->execute(array('Nota_corte1' => $Nota_corte1, 'Nota_corte2' => $Nota_corte2, 'Nota_corte3' => $Nota_corte3, 'Nota_final' => $Nota_final, 'asignatura' => $asignatura, 'estudiante' => $estudiante));
			  
				}
       return $cuenta;
 
		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}
	
	public function insertseguimiento($dateano,$periodo,$observacion,$estudiante){

		try {
			$stmt = $this->_db->prepare('Insert into seguimiento  values(:dateano,:periodo,:observacion,:estudiante)');
$stmt->execute(array('dateano' => $dateano, 'periodo' => $periodo, 'observacion' => $observacion, 'estudiante' => $estudiante));
			    
  		 
       return "exito";
 
		} catch(PDOException $e) {
		    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
		}
	}


}


?>
