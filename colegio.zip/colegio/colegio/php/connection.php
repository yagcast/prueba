<?php
    $mysql_hostname = "localhost";
    $mysql_user = "root";
    $mysql_password = "";
    $mysql_database = "colegio_gingabi";
     
	$link = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);

/* comprueba la conexión */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>