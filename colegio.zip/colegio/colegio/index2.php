<?php
 
//include config
require_once('php/config.php');
 
//check if already logged in move to home page
if(!$user->is_logged_in() ){ header('Location: index.php'); exit(); }


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Colegio</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/stilos.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<?php include 'header.php'; ?>
<div id="content">
   
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          
          <div class="widget-content">
            <div class="error_ex">
            <h2> Centro educativo infantil GIN GABI </h2>
            <h1><img src="imagen/20171025042136.png"></h1>
            
               <h2> Bienvenidos </h2>
              <h3>Por Favor Selecciona el Año Escolar Para Continuar</h3>
              
              <?php
			   $anios = $user->traer_anios();

foreach($anios as $ano){
  $nombre=  $ano["Ano_nombre"];

			  ?>
               
             <button type="button" onClick="ano(this.value)" value="<?php echo   $ano["Ano_nombre"]; ?>" class="btn btn-primary btn-circle btn-xl"><?php echo   $ano["Ano_nombre"]; ?></button> 
    <?php  } ?>
             </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  
</div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> Colegio 2017</div>
</div>
<!--end-Footer-part-->
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.calendar.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>

<script>
function ano(valor) {
 
   location.href="cursoporano.php?ano="+valor;
}
</script>
</body>
</html>
