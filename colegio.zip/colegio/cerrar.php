<?php
require_once('php/config.php');
 $user->logout();
 header('Location: index.php'); exit();
?>